//
//  DataHelper.swift
//  AirlineReservationSystem
//
//  Created by MacStudent on 2018-07-28.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class DataHelper{
    var FlightList = [Int : Flight]()
    //var PassengerList = [String : Passenger]()
    
    init(){
        self.loadFlightData()
        // self.loadPassengerData()
    }
    
    func loadFlightData(){
        FlightList = [:]
        
        do{
            
            
          // let raman =  Flight(flightID: 04, flightfrom: "India", flightto: "Canada", flightschdate: "05/08/2018", flightairlineID: 11, flightairplaneID: "AC", flightpilotID: "S01")
          //  FlightList[raman.flightID!] = raman
            
        //  let shehnaz =  Flight(flightID: 22, flightfrom: "Canada", flightto: "America", flightschdate: "22/08/2018", flightairlineID: 12, flightairplaneID: "AA", flightpilotID: "P02")
          //  FlightList[shehnaz.flightID!] = shehnaz
            
            let americanairlines =  Flight(flightID: 01, flightfrom: "Canada", flightto: "America", flightschdate: "20/07/2019", flightairlineID: AirlinesList.AirCanada, flightairplaneID: PlanetypeCategory.AirbusA300, flightpilotID: "S01")
            FlightList[americanairlines.flightID!] = americanairlines
            
            let aircanada =  Flight(flightID: 02, flightfrom: "India", flightto: "Canada", flightschdate: "12/08/2018", flightairlineID: AirlinesList.AmericanAirlines, flightairplaneID: PlanetypeCategory.Boeing747, flightpilotID: "S02")
            FlightList[aircanada.flightID!] = aircanada
           
            let russianairlines =  Flight(flightID: 03, flightfrom: "India", flightto: "Russia", flightschdate: "05/08/2018", flightairlineID: AirlinesList.JetAirways, flightairplaneID: PlanetypeCategory.IlyushinIl86, flightpilotID: "S03")
            FlightList[russianairlines.flightID!] = russianairlines
         
            let jetairways = Flight(flightID: 04, flightfrom: "India", flightto: "Canada", flightschdate: "05/08/2018", flightairlineID: AirlinesList.AirCanada, flightairplaneID: PlanetypeCategory.Boeing787Dreamliner, flightpilotID: "S04")
            FlightList[jetairways.flightID!] = jetairways
            
      //  }catch{
          //   print("Error: \(error)")
        }
        
    }
    
    
    func displayFlightInformation(){
        print("Flight Information")
        Util.drawLine()
        print("\t ID \t\t Name \t\t\t\t Flight \t\t Category \t\t Fare ")
        for(_, value) in self.FlightList.sorted(by: {$0.key < $1.key}){
            Util.drawLine()
            print("\t\(value.flightairlineID) -----\(value.flightairplaneID)")
        }
        Util.drawLine()
    }
    
    func searchFlight(flightID : Int) -> Flight?{
        if FlightList[flightID] != nil {
            return FlightList[flightID]! as Flight
        }
        else{
            print("Sorry.... The Flight You Have Entered Is Not available")
            return nil
        }
    }
    
    
    func displayFlight(){
        print("Flight Details")
        Util.drawLine()
        print("\t ID \t\t Name \t\t\t\t Flight \t\t Category \t\t Fare ")
        for(_, value) in self.FlightList.sorted(by: {$0.key < $1.key}){
            Util.drawLine()
            print("\t\(value.flightairlineID) -----\(value.flightairplaneID)")
        }
        Util.drawLine()
    }        }
    

